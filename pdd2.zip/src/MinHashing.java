/*
 * <{file_name, fun_number}, values for particular function]> -> 
 * 		<{file_name, fun_number}, {minimum_val, ?content?}>
 * Second reducer just finds minimum value for every function number for certain file.
 * Is relates to finding first 1 in column in "minhashing".
 */

import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import com.google.gson.JsonObject;

public class MinHashing extends Reducer<Text, Text, Text, Text> {

	private final static Text val_text = new Text();
	private final static int [] minimums = new int [Commons.signature_len];
	

	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		
		for(int i = 0; i < Commons.signature_len; i++)
			minimums[i] = Integer.MAX_VALUE;

		JsonObject obj = new JsonObject();
		for (Text val : values) {
			
			JsonObject tmp = JsonGetter.parseJson(val);
			String [] funs = tmp.get("values").getAsString().split(",");

			for(int j = 0; j < Commons.shingle_len; j++) {
				if(minimums[j] > Integer.parseInt(funs[j]))
					minimums[j] = Integer.parseInt(funs[j]);
			}
			
			if (tmp.has("content"))
				obj.addProperty("content", tmp.get("content").getAsString());
		}

		obj.addProperty("signature", Arrays.toString(minimums));

		val_text.set(obj.toString());
		context.write(key, val_text);
	}
}
