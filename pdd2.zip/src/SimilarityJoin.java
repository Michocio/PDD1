/*
 * Main file of project,
 * responsible for configuration
 * and running all phases.
 */

import java.io.File;
import java.net.URI;
import java.nio.file.Paths;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class SimilarityJoin {

	public static void main(String[] args) throws Exception {
		
		// Input args order: 0. directoryA 1. directoryB 2. OutputDir 3. Coeff
		
		// file path
		Commons.coeff_path = new String(Paths.get(args[3]).getFileName().toString());

		String dirA = args[0];
		String dirB = args[1];
		String output = args[2];

		Configuration conf1 = new Configuration();

		Job shinglesJob = Job.getInstance(conf1, "shingles");
		shinglesJob.addCacheFile(new URI(args[3]));

		shinglesJob.setJarByClass(SimilarityJoin.class);
		shinglesJob.setInputFormatClass(WholeFileInputFormat.class);

		shinglesJob.setMapperClass(ShingleSplitter.class);
		shinglesJob.setReducerClass(ShingleHashing.class);

		shinglesJob.setOutputKeyClass(Text.class);
		shinglesJob.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(shinglesJob, new Path(dirA));
		FileInputFormat.addInputPath(shinglesJob, new Path(dirB));
		FileOutputFormat.setOutputPath(shinglesJob, new Path(output));
		
		FileSystem hdfs = FileSystem.get(conf1);

		// /////////////////////////////////////////////////////////////
		// ///////////
		// ////////////////////////////////////////////////////////////
		Configuration conf2 = new Configuration();
		Job minHashing = Job.getInstance(conf2, "minhashing");
		if (shinglesJob.waitForCompletion(true)) {

			minHashing.setJarByClass(SimilarityJoin.class);
			minHashing.setInputFormatClass(KeyValueTextInputFormat.class);

			minHashing.setMapperClass(DummyMapper.class);
			minHashing.setReducerClass(MinHashing.class);

			minHashing.setOutputKeyClass(Text.class);
			minHashing.setOutputValueClass(Text.class);

			FileInputFormat.addInputPath(minHashing, new Path(output));
			FileOutputFormat.setOutputPath(minHashing, new Path(output + "_2"));

			if (minHashing.waitForCompletion(true)) {
				
				// delete directory of previous worker - for debug purposes I don't
				// delete directories during chain.
				/*if (hdfs.exists(new Path(output))) {
				    hdfs.delete(new Path(output), true);
				}*/
				
				Configuration conf3 = new Configuration();

				Job Banding = Job.getInstance(conf3, "bands");

				Banding.setJarByClass(SimilarityJoin.class);
				Banding.setInputFormatClass(KeyValueTextInputFormat.class);

				Banding.setMapperClass(Banding.class);
				Banding.setReducerClass(BandsHashing.class);

				Banding.setOutputKeyClass(Text.class);
				Banding.setOutputValueClass(Text.class);

				FileInputFormat.addInputPath(Banding, new Path(output + "_2"));
				FileOutputFormat.setOutputPath(Banding, new Path(output + "_3"));

				if (Banding.waitForCompletion(true)) {
					Configuration conf4 = new Configuration();

					Job lshJob = Job.getInstance(conf4, "lsh");

					lshJob.setJarByClass(SimilarityJoin.class);
					lshJob.setInputFormatClass(KeyValueTextInputFormat.class);

					lshJob.setMapperClass(DummyMapper.class);
					lshJob.setReducerClass(PairsReducer.class);

					lshJob.setOutputKeyClass(Text.class);
					lshJob.setOutputValueClass(Text.class);

					FileInputFormat.addInputPath(lshJob, new Path(output + "_3"));
					FileOutputFormat.setOutputPath(lshJob,
							new Path(output + "_4"));

					if (lshJob.waitForCompletion(true)) {
						Configuration conf5 = new Configuration();

						Job dataGathering = Job.getInstance(conf5, "pairs");

						dataGathering.setJarByClass(SimilarityJoin.class);
						dataGathering.setInputFormatClass(KeyValueTextInputFormat.class);

						dataGathering.setMapperClass(DummyMapper.class);
						dataGathering.setReducerClass(GatheringData.class);

						dataGathering.setOutputKeyClass(Text.class);
						dataGathering.setOutputValueClass(Text.class);

						FileInputFormat.addInputPath(dataGathering, new Path(output + "_4"));
						FileOutputFormat.setOutputPath(dataGathering, new Path(output + "_5"));
						if (dataGathering.waitForCompletion(true)) {
							Configuration conf6 = new Configuration();

							Job finalRenaming = Job.getInstance(conf6, "final");

							finalRenaming.setJarByClass(SimilarityJoin.class);
							finalRenaming.setInputFormatClass(KeyValueTextInputFormat.class);

							finalRenaming.setMapperClass(DummyMapper.class);
							finalRenaming.setReducerClass(FinalPairing.class);

							finalRenaming.setOutputKeyClass(Text.class);
							finalRenaming.setOutputValueClass(Text.class);

							FileInputFormat.addInputPath(finalRenaming, new Path(output + "_5"));
							FileOutputFormat.setOutputPath(finalRenaming, new Path(output + "_final"));
							System.exit(finalRenaming.waitForCompletion(true) ? 0 : 1);
						}
					}

				}
			}
		}
	}
}
